defmodule PrimerEntregableTest do
  use ExUnit.Case
  doctest PrimerEntregable

  test "greets the world" do
    assert PrimerEntregable.hello() == :world
  end
end
